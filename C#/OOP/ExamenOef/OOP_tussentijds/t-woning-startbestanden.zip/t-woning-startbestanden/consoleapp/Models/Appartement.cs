using System;

namespace consoleapp.Models
{
    public class Appartement
    {
    }
}
using System;

namespace consoleapp.Models
{


    public static class FileOperations
    {
    }
}
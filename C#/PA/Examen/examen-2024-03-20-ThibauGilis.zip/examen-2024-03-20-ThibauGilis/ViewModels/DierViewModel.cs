﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EindExamenMaui.ViewModels
{
    public partial class DierViewModel : BaseViewModel
    {
        private int _dierIndex;

        [ObservableProperty]
        private Dier selectedDier;
        [ObservableProperty]
        private string naam;
        [ObservableProperty]
        private string geslacht;
        [ObservableProperty]
        private Soort soort;


        [ObservableProperty]
        private ObservableCollection<Dier> dierenLijst;
        [ObservableProperty]
        private ObservableCollection<Soort> soortenLijst;

        private IDierRepository _dierRepository;
        private ISoortRepository _soortRepository;

        public DierViewModel(DierRepository dierRepository, SoortRepository soortRepository)
        {
            _dierRepository = dierRepository;
            _soortRepository = soortRepository;

            DierenLijst = new ObservableCollection<Dier>(dierRepository.DierenOphalen());
            SoortenLijst = new ObservableCollection<Soort>(soortRepository.SoortenOphalen());

            Title = "Dier beheren Thibau Gilis";
        }

        [ObservableProperty]
        public string actieLabel = "Nieuw dier toevoegen";

        partial void OnSelectedDierChanged(Dier value)
        {
            if (value == null) { return; }
            if (value.Id == 0)
            {
                ActieLabel = "Nieuw dier toevoegen";
            }
            else
            {
                for (int i = 0; i < DierenLijst.Count; i++)
                {
                    if (value.Id == DierenLijst[i].Id)
                    {
                        _dierIndex = i;
                    }
                }
                ActieLabel = "Dier wijzigen";
                Naam = value.Naam;
                Geslacht = value.Geslacht;

                foreach(Soort soort in SoortenLijst)
                {
                    if (soort.Id == value.SoortId) 
                    {
                        Soort = soort;
                        break; 
                    }
                }
            }
        }


        [RelayCommand]
        private void Toevoegen()
        {
            if (string.IsNullOrWhiteSpace(Naam) || string.IsNullOrWhiteSpace(Geslacht) || Soort == null) return;

            int id = DierenLijst.Count == 0 ? 0 : DierenLijst.Last().Id + 1;

            DierenLijst.Add(
                new Dier(
                id,
                Naam,
                Soort.Id,
                Geslacht
                ));
            Deselecteren();
        }
        [RelayCommand]
        private void Wijzigen()
        {
            if (ActieLabel == "Nieuw dier toevoegen") return;

            DierenLijst[_dierIndex] = new Dier(DierenLijst[_dierIndex].Id, Naam,Soort.Id, Geslacht);
            Deselecteren();
        }
        [RelayCommand]
        private void Verwijderen()
        {
            if (ActieLabel == "Nieuw dier toevoegen") return;

            DierenLijst.RemoveAt(_dierIndex);
            Deselecteren();
        }
        [RelayCommand]
        private void Deselecteren()
        {
            Naam = "";
            Geslacht = "";
            Soort = new Soort();
            ActieLabel = "Nieuw dier toevoegen";
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EindExamenMaui.ViewModels
{
    public partial class EigenaarOverzichtViewModel : BaseViewModel
    {
        [ObservableProperty]
        string zoektermEigenaar;
        [ObservableProperty]
        public ObservableCollection<Persoon> personen;

        private IPersoonRepository _persoonRepository;
        public EigenaarOverzichtViewModel(PersoonRepository persoonRepository)
        {
            ZoektermEigenaar = string.Empty;
            _persoonRepository = persoonRepository;
            Title = "Overzicht dieren Thibau Gilis";
        }

        [RelayCommand]
        private void ZoekEigenaar()
        {
            Personen = new ObservableCollection<Persoon>(_persoonRepository.OphalenPersonen(ZoektermEigenaar));
        }
    }
}

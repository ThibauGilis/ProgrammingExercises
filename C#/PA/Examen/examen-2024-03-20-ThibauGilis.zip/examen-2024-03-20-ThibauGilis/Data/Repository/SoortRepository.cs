﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EindExamenMaui.Data.Repository
{
    public class SoortRepository : BaseRepository, ISoortRepository
    {
        public IEnumerable<Soort> SoortenOphalen()
        {
            var connection = new SqlConnection(ConnectionString);
            var sql = "select * from Soort";
            return connection.Query<Soort>(sql).ToList();
        }
    }
}

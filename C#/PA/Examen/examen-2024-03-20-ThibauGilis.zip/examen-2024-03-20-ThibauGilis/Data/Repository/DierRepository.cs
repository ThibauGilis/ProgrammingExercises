﻿using EindExamenMaui.Data.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EindExamenMaui.Data.Repository
{
    public class DierRepository : BaseRepository, IDierRepository
    {
        public IEnumerable<Dier> DierenOphalen()
        {
            var connection = new SqlConnection(ConnectionString);
            var sql = "select * from Dier";
            return connection.Query<Dier>(sql).ToList();
        }
    }
}

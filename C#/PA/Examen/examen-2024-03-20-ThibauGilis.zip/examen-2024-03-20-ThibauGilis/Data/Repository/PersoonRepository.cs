﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EindExamenMaui.Data.Repository
{
    public class PersoonRepository : BaseRepository, IPersoonRepository
    {
        public IEnumerable<Persoon> OphalenPersonen(string zoekterm)
        {
            string sql = @"SELECT P.*, '' AS SplitCol, E.*, '' AS SplitCol, D.*
                    FROM Persoon P
                    LEFT JOIN Eigenaar E on P.Id = E.persoonId
                    LEFT JOIN Dier D on D.id = E.dierId                            
                    WHERE CONCAT(voornaam, SPACE(1), achternaam) LIKE '%' + @zoekterm + '%' ORDER BY voornaam";
            using (IDbConnection db = new SqlConnection(ConnectionString))
            {
                var personen = db.Query<Persoon, Eigenaar, Dier, Persoon>(sql,
                    (persoon, eigenaar, dier) =>
                    {
                        dier.Eigenaars = [eigenaar];
                        persoon.Eigenaars = [eigenaar];

                        return persoon;
                    }, new { zoekterm = zoekterm }, splitOn: "SplitCol");

                var gegroepeerdePersonen = GroepeerPersonen(personen);

                return gegroepeerdePersonen;
            }
        }

        private static List<Persoon> GroepeerPersonen(IEnumerable<Persoon> personen)
        {
            var gegroepeerd = personen.GroupBy(p => p.Id);

            return gegroepeerd.Select(g =>
            {
                var persoon = g.First();
                persoon.Eigenaars = g.Select(p => p.Eigenaars.Single()).ToList();
                return persoon;
            }).ToList();
        }
    }
}

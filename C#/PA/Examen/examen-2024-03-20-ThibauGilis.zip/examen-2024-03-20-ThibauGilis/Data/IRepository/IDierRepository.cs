﻿

namespace EindExamenMaui.Data.IRepository
{
    public interface IDierRepository
    {
        public IEnumerable<Dier> DierenOphalen();
    }
}

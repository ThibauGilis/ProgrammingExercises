﻿

namespace EindExamenMaui.Models
{
    public class Dier
    {
        public Dier() 
        { 
        }

        public Dier(int id, string naam, int soortId, string geslacht) 
        { 
            Id = id;
            Naam = naam;
            SoortId = soortId;
            Geslacht = geslacht;
        }

        public int Id { get; set; }
        public string Naam { get; set; }
        public int SoortId { get; set; }

        public string Geslacht { get; set; }

        public ICollection<Eigenaar> Eigenaars { get; set; }

        public override string ToString()
        {
            return Naam;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EindExamenMaui.Models
{
    public class Persoon
    {
        public int Id { get; set; }
        public string Achternaam { get; set; }
        public string Voornaam { get; set; }
        public string Telefoon { get; set; }
        public string Email { get; set; }

        public ICollection<Eigenaar> Eigenaars { get; set; }

        public override string ToString()
        {
            return $"{Voornaam} {Achternaam}";
        }
    }
}

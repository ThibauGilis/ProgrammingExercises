﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EindExamenMaui.Models
{
    public class Eigenaar
    {
        public int Id { get; set; }
        public int DierId { get; set; }
        public int PersoonId { get; set; }

    }
}

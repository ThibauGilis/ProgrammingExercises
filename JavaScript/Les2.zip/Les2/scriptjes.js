function toonboodschap()
{
    const postcode = prompt("wat is uw psotcode", "2250");
    const gemeente = prompt("wat is uw gemeente", "olen");
    alert(postcode + " " + gemeente)
    document.getElementById
}